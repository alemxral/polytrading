### Security

If you believe you’ve found a security vulnerability, please email security@polymarket.com. Do not open a public issue.

Include:
- A description of the issue and potential impact
- Steps to reproduce or a minimal proof of concept
- Any relevant logs or environment details

We will acknowledge receipt, investigate, and provide guidance on next steps.


